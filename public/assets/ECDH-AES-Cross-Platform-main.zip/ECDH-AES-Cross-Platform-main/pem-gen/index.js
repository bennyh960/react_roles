const fs = require('fs');
const { exec, execSync } = require("child_process");
const { parse } = require("csv-parse");
const { stringify } = require("csv-stringify");
const writableStream = fs.createWriteStream('output.csv');
const columns = ["PIPId", "ISOPrivateKey", "ISOPublicKey"];

const stringifier = stringify({ header: true, columns: columns });

fs.createReadStream("./input.csv")
  .pipe(parse({ delimiter: ",", from_line: 2 }))
  .on("data", function (row) {
    console.log("creating keys for " + row[0]);
    var output = makeKeys(row[0]);
    stringifier.write(output);
  })
  .on("end", function () {
    stringifier.pipe(writableStream);
    console.log("finished");
  })
  .on("error", function (error) {
    console.log(error.message);
  });

function makeKeys(id){
  generatePrivateKey(id);
  generatePublicKey(id);
  const privatePem = fs.readFileSync("./pems/"+ id+ ".pem");
  const publicPem = fs.readFileSync("./pems/"+ id+ "_pub.pem");
  return [id, privatePem.toString('base64'), publicPem.toString('base64')];
}

function generatePrivateKey(id){
  execSync("openssl ecparam -name prime256v1 -genkey -noout -out ./pems/"+ id+ ".pem");
}

function generatePublicKey(id){
  execSync("openssl ec -in ./pems/"+ id+ ".pem -pubout -out ./pems/"+ id+ "_pub.pem");
}
