# ECDH and AES Cross Platform test

## Prerequisites
Before running this you must install [Node.js](https://nodejs.org/) which will also install the node package manager (npm).

## Installing Dependencies
Once installed you must install the dependencies for this app by running

```
npm install
```

## Running the application
```
node server.js
```

## Notes/Known Issues
- In VSCode while debugging the prompt function for user input doesn't work correctly. If this is an issue then input the data another way.