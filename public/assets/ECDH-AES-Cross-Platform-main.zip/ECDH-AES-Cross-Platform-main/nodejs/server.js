var crypto = require('crypto');
var assert = require('assert');
var fs = require('fs');
const { exit } = require('process');
const { Console } = require('console');
const prompt = require("prompt-sync")();
const {encrypt, decrypt, ECDHKeyExchange, sha256} = require ('./cryptoUtils');

const message = JSON.parse(fs.readFileSync("../resources/PACS.008-Payment.json"));
const curve = 'prime256v1';
const algo = "aes-256-cbc";
const outputEncoding ="base64";


console.log("Welcome to ECDH and AES-256-CBC cross platform test!!!");
console.log("Loading Alice's keys from PEMs...");
const alicePem = fs.readFileSync("../resources/alice.pem");
const alicePrivateKey = crypto.createPrivateKey(alicePem);
const alicePubPem = fs.readFileSync("../resources/alice_pub.pem");
const alicePublicKey = crypto.createPublicKey(alicePubPem);
if (!alicePrivateKey && !alicePublicKey) {
    console.log("Failed to load Alice's keys");
    exit(1);
}

else {
    console.log("Alice's keys created successfully");
}

console.log("Loading Bob's keys from PEMs...");
const bobPem = fs.readFileSync("../resources/bob.pem");
const bobPrivateKey = crypto.createPrivateKey(bobPem);
const bobPubPem = fs.readFileSync("../resources/bob_pub.pem");
const bobPublicKey = crypto.createPublicKey(bobPubPem);

if (!bobPrivateKey && !bobPublicKey) {
    console.log("Failed to load Bob's keys");
    exit(1);
}
else {
    console.log("Bob's keys created successfully");
}

console.log("Performing ECDH key exchange");
const aliceSecret = ECDHKeyExchange(alicePrivateKey, bobPublicKey);
const bobSecret = ECDHKeyExchange(bobPrivateKey, alicePublicKey);

console.log("Shared secret before SHA256 (in b64): " + aliceSecret.toString(outputEncoding));
assert.strictEqual(aliceSecret.toString(outputEncoding), bobSecret.toString(outputEncoding), "Alice and Bob's shared secrets do not match!");

// Perform hash to create the key from secret (and for .NET compatability)
const aliceSecretKey = sha256(aliceSecret);
const bobSecretKey = sha256(bobSecret);

console.log("Shared secret key after SHA256. To be used for encryption (in b64): "+ aliceSecretKey.toString(outputEncoding));
assert.strictEqual(aliceSecretKey.toString(outputEncoding), bobSecretKey.toString(outputEncoding), "Alice and Bob's shared secret keys do not match!"); 

//Encrypt the JSON object string
var jsonString = JSON.stringify(message);

var iv = crypto.randomBytes(16);
console.log("..................................................................................");
console.log("Initialisation Vector(IV) (in b64): " + iv.toString(outputEncoding));

const encrypted = encrypt(algo, aliceSecretKey, iv, jsonString, outputEncoding);
console.log("Encrypted data using Alice's secret key (in b64): " + encrypted);

console.log("Copy and Paste this IV and Encrypted Data into one of the other language apps.");
console.log("..................................................................................");

var inputIV = prompt("Paste the IV from the other language app (in b64): ");
iv = Buffer.from(inputIV, outputEncoding);
if (iv.length != 16){
    console.log("Invalid IV length! Length must be 16bytes, supplied length: " + iv.length);
}
    
var inputEncrypted = prompt("Paste the encrypted data from the other language app (in b64): ");

const decrypted = decrypt(algo, bobSecretKey, iv, inputEncrypted, outputEncoding);

console.log("Data decrypted using Bob's secret key: " + decrypted);

try{
    const obj = JSON.parse(decrypted);
    if (obj){
        console.log("JSON object parses successfully!!!!");
        process.exit(0);
    } 
    else {
        console.log("JSON object didn't parse....");
        process.exit(1);
    }
}catch(e){
    console.log("Error occured parsing object: " + e.toString());
    process.exit(1);
}



