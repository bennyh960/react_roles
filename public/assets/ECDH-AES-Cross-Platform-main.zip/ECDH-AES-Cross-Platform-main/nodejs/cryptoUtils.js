var crypto = require('crypto');

function ECDHKeyExchange(privKey, pubKey){
    return crypto.diffieHellman({privateKey: privKey, publicKey: pubKey});
}

function sha256(value){
    const hash = crypto.createHash('sha256');
    hash.update(value);
    return hash.digest(); 
}

function encrypt (algorithm, key, iv, stringToEncrypt, outEncoding){
    const cipher = crypto.createCipheriv(algorithm, key, iv);

    let encrypted = cipher.update(stringToEncrypt, 'utf8', outEncoding);
    encrypted += cipher.final(outEncoding);
    return encrypted;
}

function decrypt (algorithm, key, iv, stringToDecrypt, inEncoding){
    const decipher = crypto.createDecipheriv(algorithm, key, iv);
    let decrypted = decipher.update(stringToDecrypt, inEncoding, 'utf8');
    decrypted += decipher.final('utf8');
    return decrypted;
}

module.exports = {ECDHKeyExchange, sha256, encrypt, decrypt};