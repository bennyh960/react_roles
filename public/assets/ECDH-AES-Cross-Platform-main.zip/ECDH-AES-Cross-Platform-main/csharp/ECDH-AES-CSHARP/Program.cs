﻿using System;
using System.Diagnostics;
using System.Diagnostics.Metrics;
using System.IO;
using System.Net.Sockets;
using System.Runtime.CompilerServices;
using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using System.Text.Json.Nodes;
using static System.Runtime.InteropServices.JavaScript.JSType;

public class RosalindKeyTest
{


    private static void Main(string[] args)
    {

        Console.WriteLine("Welcome to ECDH and AES-256-CBC cross platform test!!!");

        JsonNode message  = JsonNode.Parse(File.ReadAllText(@".\resources\PACS.008-Payment.json"));
        if (message == null )
        {
            Console.WriteLine("Can't parse json.");
            System.Environment.Exit(1);
        }
        
        Console.WriteLine("Loading Alice's keys from PEMs...");

        ECDiffieHellmanCng alicePrivate = new ECDiffieHellmanCng(ECCurve.NamedCurves.nistP256);
        alicePrivate.ImportFromPem((ReadOnlySpan<char>)File.ReadAllText(@".\resources\alice.pem"));

        ECDiffieHellmanCng alicePublic = new ECDiffieHellmanCng(ECCurve.NamedCurves.nistP256);
        alicePublic.ImportFromPem((ReadOnlySpan<char>)File.ReadAllText(@".\resources\alice_pub.pem"));

        if (alicePrivate != null && alicePublic != null)
        {
            Console.WriteLine("Alice's keys created successfully");
        }
        else
        {
            Console.WriteLine("Failed to load Alice's keys");
            System.Environment.Exit(1);
        }

        Console.WriteLine("Loading Bobs's keys from PEMs...");

        ECDiffieHellmanCng bobPrivate = new ECDiffieHellmanCng(ECCurve.NamedCurves.nistP256);
        bobPrivate.ImportFromPem((ReadOnlySpan<char>)File.ReadAllText(@".\resources\bob.pem"));

        ECDiffieHellmanCng bobPublic = new ECDiffieHellmanCng(ECCurve.NamedCurves.nistP256);
        bobPublic.ImportFromPem((ReadOnlySpan<char>)File.ReadAllText(@".\resources\bob_pub.pem"));

        if (bobPrivate != null && bobPublic != null)
        {
            Console.WriteLine("Bob's keys created successfully");
        }
        else
        {
            Console.WriteLine("Failed to load bob's keys");
            System.Environment.Exit(1);
        }

        //perform key swaps
        byte[] aliceSecretKey = alicePrivate.DeriveKeyMaterial(bobPublic.PublicKey);
        byte[] bobSecretKey = bobPrivate.DeriveKeyMaterial(alicePublic.PublicKey);

        Console.WriteLine("" +
            "Shared secret key after SHA256. To be used for encryption (in b64): " + Convert.ToBase64String(aliceSecretKey)); 

        // check keys match
        if (!Convert.ToBase64String(aliceSecretKey).Equals(Convert.ToBase64String(bobSecretKey))){
            Console.WriteLine("Alice and Bob's shared secret keys do not match!");
            System.Environment.Exit(1);
        }


        byte[] iv = CreateIV();
        Console.WriteLine("..................................................................................");
        Console.WriteLine("Initialisation Vector(IV) (in b64): " + Convert.ToBase64String(iv));

        byte[] encrypted = EncryptStringToBytes_Aes(message.ToJsonString(null), aliceSecretKey, iv);
        Console.WriteLine("Encrypted data using Alice's secret key (in b64): " + Convert.ToBase64String(encrypted));

        Console.WriteLine("Copy and Paste this IV and Encrypted Data into one of the other language apps.");
        Console.WriteLine("..................................................................................");

        Console.Write("Paste the IV from the other language app(in b64): ");
        string inputIV = Console.ReadLine();
        iv = Convert.FromBase64String(inputIV);

        Console.Write("Paste the encrypted data from the other language app (in b64):  ");
        encrypted = Convert.FromBase64String(Console.ReadLine());

        string decrypted = DecryptStringFromBytes_Aes(encrypted, bobSecretKey, iv);
        Console.WriteLine("Data decrypted using Bob's secret key: " + decrypted);

        message = JsonNode.Parse(decrypted);
        if (message == null)
        {
            Console.WriteLine("JSON object didn't parse....");
            System.Environment.Exit(1);
        }
        else
        {
            Console.WriteLine("JSON object parses successfully!!!!");
        }

    }

    static byte[] CreateIV()
    {
        byte[] response = new Byte[16];
        RNGCryptoServiceProvider rng = new RNGCryptoServiceProvider();
        rng.GetBytes(response);
        return response;
    }

    //Encrypt and Decrypt methods taken from https://learn.microsoft.com/en-us/dotnet/api/system.security.cryptography.aesmanaged?redirectedfrom=MSDN&view=net-7.0
    static string DecryptStringFromBytes_Aes(byte[] cipherText, byte[] Key, byte[] IV)
    {
        // Check arguments.
        if (cipherText == null || cipherText.Length <= 0)
            throw new ArgumentNullException("cipherText");
        if (Key == null || Key.Length <= 0)
            throw new ArgumentNullException("Key");
        if (IV == null || IV.Length <= 0)
            throw new ArgumentNullException("IV");

        // Declare the string used to hold
        // the decrypted text.
        string plaintext = null;

        // Create an AesManaged object
        // with the specified key and IV.
        using (Aes aesAlg = Aes.Create())
        {
            aesAlg.Key = Key;
            aesAlg.IV = IV;
            aesAlg.Mode = CipherMode.CBC;
            aesAlg.Padding = PaddingMode.PKCS7;

            // Create a decryptor to perform the stream transform.
            ICryptoTransform decryptor = aesAlg.CreateDecryptor(aesAlg.Key, aesAlg.IV);

            // Create the streams used for decryption.
            using (MemoryStream msDecrypt = new MemoryStream(cipherText))
            {
                using (CryptoStream csDecrypt = new CryptoStream(msDecrypt, decryptor, CryptoStreamMode.Read))
                {
                    using (StreamReader srDecrypt = new StreamReader(csDecrypt))
                    {

                        // Read the decrypted bytes from the decrypting stream
                        // and place them in a string.
                        plaintext = srDecrypt.ReadToEnd();
                    }
                }
            }
        }

        return plaintext;
    }

    static byte[] EncryptStringToBytes_Aes(string plainText, byte[] Key, byte[] IV)
    {
        // Check arguments.
        if (plainText == null || plainText.Length <= 0)
            throw new ArgumentNullException("plainText");
        if (Key == null || Key.Length <= 0)
            throw new ArgumentNullException("Key");
        if (IV == null || IV.Length <= 0)
            throw new ArgumentNullException("IV");
        byte[] encrypted;

        // Create an AesManaged object
        // with the specified key and IV.
        using (AesManaged aesAlg = new AesManaged())
        {
            aesAlg.Key = Key;
            aesAlg.IV = IV;

            // Create an encryptor to perform the stream transform.
            ICryptoTransform encryptor = aesAlg.CreateEncryptor(aesAlg.Key, aesAlg.IV);

            // Create the streams used for encryption.
            using (MemoryStream msEncrypt = new MemoryStream())
            {
                using (CryptoStream csEncrypt = new CryptoStream(msEncrypt, encryptor, CryptoStreamMode.Write))
                {
                    using (StreamWriter swEncrypt = new StreamWriter(csEncrypt))
                    {
                        //Write all data to the stream.
                        swEncrypt.Write(plainText);
                    }
                    encrypted = msEncrypt.ToArray();
                }
            }
        }

        // Return the encrypted bytes from the memory stream.
        return encrypted;
    }

   
}
