# ECDH-AES-Cross-Platform - C#
A suite of test applications across Node JS, java and C# that each perform ECDH based  (Prime256v1/NISTP256 curve) and then uses AES-256-CBC to encrypt a JSON payload for sharing between the apps


## Notes/Known Issues
- This was built and run by debugging in Visual Studio. I haven't published the exe, so do this as you wish.
- Visual Studio wouldn't allow me to add resources from the common resources folder because it was out. As such they have been copied to a local resources project Please edit the paths according to your requirements.
