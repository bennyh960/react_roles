# ECDH-AES-Cross-Platform
A suite of test applications across Node JS, java and C# (windows) that each perform ECDH based on the Prime256v1/NISTP256 curve and then uses AES-256-CBC to encrypt a JSON payload for sharing between the apps.

## Generating the Keys with OpenSSL
This command generates both the private and public key PEM (public is contained within the private for EC keys). We use the prime256v1/NISTP256 curve

```
openssl ecparam -name prime256v1 -genkey -noout -out key.pem
```

## Exporting just the Public Key PEM
For the key distribution the public key alone must be extracted. As mentioned above as the public key is part of the private key we need to extract it.
```
openssl ec -in alice.pem -pubout -out alice_pub.pem
```

## Establishing the shared secret key (to SHA or not to SHA...)
These application use Elliptic Curve Diffie Hellman to establish a shared secret. Put simplistically this is because with Elliptic Curve keys:
```
(Alice's private key x Bob's public key) = (Bob's private key x ALice publc key) 
```

So assuming the shared secret is estalished by multiplying your private key with the other party's public key. In the .NET libraries this shared secret is then hashed with a SHA256 has algorirthm to create the key. This is mandatory in .NET and doesn't happen in the nodeJS or Java libraries. Therefore to maintain interoperability the SHA must be performed manually in nodeJs and Java as outlined in this table.

Platform | Must SHA256 the secret to create the Key
------------ | -------------
C#| No (performed by the CNG library automatically)
nodeJS| Yes
Java| Yes

## Running the apps
Following the specific instructions for the different languages (being mindful of the resources files and folders, you may have to move these around). All the apps perform the same functions in the same order:

1. Load Alice and Bob's keys from PEM files
2. Load the sample JSON
3. Establish the shared secret key and check that Alice's key is the same as Bob's
4. Create a random Initialisation Vector (IV)
5. Encrypt the JSON using Alice's shared secret key and the IV
6. Print the IV and encrypted text in base64 encoding to the console.

After this it should look like this:
```
Welcome to ECDH and AES-256-CBC cross platform test!!!
Loading Alice's keys from PEMs...
Alice's keys created successfully
Loading Bob's keys from PEMs...
Bob's keys created successfully
Performing ECDH key exchange
Shared secret before SHA256 (in b64): t3gR4358Np7kN1xOCe9s55/xk2xli3TjWfmRRPoCexY=
Shared secret key after SHA256. To be used for encryption (in b64): IrtGYdAyEgti85wwyBuEnER0iA7xIQjnZNv1lbp+1fc=
..................................................................................
Initialisation Vector(IV) (in b64): M1zv2XumqJl8afKp+StMBw==
Encrypted data using Alice's secret key (in b64): V+u4JJ7iObAdwCMbQjYw3X9Vve+8lPHO+El/RvLRRK/3qsir5qlyktTR4Bc29sp0Ew+cpISISGC4MQ+CfN/A3DjH4Py7s1AuwT34pvTr3TTfODURtfYP6JQdsy7emEHcctpUgp9huPP4xE6lp+UdzMj3BXB3QFtJ9ImIAiRHH+zuf5rHwTMrj0o89//KSrwsgXu5G2jvC3noMPz9/tji1Dxp0991N4qhs+McWP1cHDU0MFmQc1hrlCFPrgGSfn2gUiaX8wLOMvQKDEb/Sne7aRA0sKdvW/plUW1lgCyI8Uy8hnZ/9RFl+qWXotz7CKtzw2iKaDCKEwr3IivtR+1l+09EaSgXoO7dU3hb4V3PqoAdEwi9UfnFWT8lqGpIUnBDcqQKyMdU4EyxKOlISt5YfY/Gg06QA+ZXFrs41Na5Hfj6+pISsR64azleRKHKofMyGohjMJXdVfAK4AfLyUL1Q7NVuqvVCVNA/fBxo9KFs3zfyjsOdNPhrby8MIYmMbgsFZnYXYc3+Rov/GfbpmCIq8lyJPjoDHqzou7bayFZeMN7TnX7ogmNE9+D3c8wtDF5+G1MGCN32QngS5SXGhv9KRtQF+G5L2dACsjw/pgI7SSWeA1zpcLjg2Iz9FD8+OXBT+jn3UW9HGLK1/mPwB3Zhzw5zTp+0KHvRUO63koOBc5hUUXB6I6rh0o3PC6jFnVDHQTy5Z0CmhhhUrbq5hGhkjyVyl03VfRR41K1+wrEodP6bwxwXDcPuwMwXkTz6BP2iae+Wg31WdeNsaeGv4lmQ7QB4gJlQ3rgKwyI7ViWph4xKYqrof3bEABCYf1DCWITSFByAYsiK7DuE5QL1W/IJv93aDVV2hff0cg7DWjLD1gj1vIdq4Dsi/6jrf4MAF4kweNM0qHg65qi1jWDs1GCMsqxcXjzxk8Q84UW6YPYeU39tmcVOf2KC48s8m2PZBqKbDVUwajdiqPVCIN4h4NFp9x4mT8tLW+OrhTmDO5cce3vO1fFifKh5j3InftI8tYlPqI2zkWh76WxADC32/TCKkAxSV1AhTCnMOqlDv6Qc62uQWbO8Ds9JHmQ4ehO9gWP849fecGszaZJVQ+Uc8+0QViPRX4wvSbqmJVR7Kjq3ZcRpnUSHPtp269FzOWa4OMnjcdo1WO87oxHThL+gvXC8kMHpDpe7Prgn76OJHORODNDR5WPMJ72CkCRwRi/pZG8kJAHEcEmRjW38w1OUVoYrWGZG3bApo8AhH3KEgyOWByJCqKPaEzwSaf0EjmN2yPGOvH/DkQHbIYgN/QRBDp8Q9T8W4zaI3d+RZLh1un/FxQmrai2o27nYepSKLvlYnY8juDsxOJrUqyY29A5eHc39ZXeJUrp83hInhZ34nnsuK73rDnBEtPnWkg74lE8LHBoA+eR8ophcERJmuEfyTFCq9MakhA7xtgtojHAYEAVii39k7WZ7Asn4bErvxZ3MUlYuhEmPxCiUsS3jkOPi731yJAtOvxE1jgGDTjCSKGnUdK7MstOplSbk6q8rFAEUj0G+4Y037hojg+tpXFt3yc/FR0P0mgA5QKhzV1tJyw5F89fmtr2ePOqrAdb8sE3fGB6ryguGqe7TqosUkYajYJ0Qz8d796rGH4c2t4uhhwGJ+rXldi928cmJJpM/J7XwQrM3h6fBxBwnd//+qcaJyQQrKI4mZm+Sx4k8nEaig3ufl+PnIVHfimkz0klDIS8jxkyfoEQNb6aSBT5My46/mCSbtE/4ahus14o6oHCzIjwDUceoNo8GNpzoODDJpvUSWsUldJENBloqC4fgVa46Vi/1929iz3b2V79cPcdD9z0FuHQ6FGmoamTnPDuuxj1Uvs/wQDyo3hNSgMAVmMwkkW9QzW9qEQ/23Gn55+XYBBPCGXNUf+LFawl8e5AFj+v7p8LH9OczQfWXa4R38WTJYJOGOLuDQ382xbQaCHKyL11Qjpb2CY93QSaXmeaMlIl5w1B6+LARj/p0HBOtQo2OKsnn7Hl6THvepej1dWpmn+FBFc=
Copy and Paste this IV and Encrypted Data into one of the other language apps.
..................................................................................
Paste the IV from the other language app (in b64):
```

Then copy and paste the IV and encryted data from one of the other language applications. The app will then:

7. Decrypt the data using Bob's shared secret key and the supplied initialisation vector

8. Confirm that the decrypted data can be parsed back into a JSON object (i.e that it has been corrupted)
