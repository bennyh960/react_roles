# ECDH and AES Cross Platform test - JAVA

## Prerequisites
Before running this you must install:
- java and jre
- maven

if you don't have these they can be downloaded or installed via VSCode Extensions.

## Installing Dependencies
Once installed you must install the dependencies for this app as this app uses bouncy castle for processing the PEMs. However this should be handled automatically by your maven plugin.

## Notes/Known Issues
- To work with Symmetric keys over 128 bits requires a policy change in Java. In older verson it requires a policy files to be installed wih your jdk, newer versions can handled with following line of code. More informatio on this can be found in step 3 [of this blog](https://www.baeldung.com/java-bouncy-castle)
``` 
Security.setProperty("crypto.policy", "unlimited");
```
- This was built and run using the java plugin in VSCode, so I haven't used the maven build and package calls.
- Equally the java plugin allowed me to debug the application with the files remaining in the common resources folder. Please edit the paths according to your requirements.

