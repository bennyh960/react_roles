package com.ecdh_aes.demo;
import java.security.InvalidKeyException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.PublicKey;

import javax.crypto.KeyAgreement;

public class CryptoUtils {
    public static byte[] sha256(byte[] input)  throws NoSuchAlgorithmException{
        MessageDigest hash = MessageDigest.getInstance("SHA-256");
        hash.update(input);
        return hash.digest();
    }

    public static byte[] ECDHKeyExchange( PrivateKey privateKey, PublicKey publicKey) throws NoSuchAlgorithmException, InvalidKeyException{
        KeyAgreement ka = KeyAgreement.getInstance("ECDH");
        ka.init(privateKey);
        ka.doPhase(publicKey, true);
        // Return shared secret
        return ka.generateSecret();
    }
    
}
