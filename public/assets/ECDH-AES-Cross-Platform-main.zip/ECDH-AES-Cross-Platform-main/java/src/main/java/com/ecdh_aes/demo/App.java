package com.ecdh_aes.demo;

import java.security.KeyPair;
import java.security.PublicKey;
import java.security.SecureRandom;
import java.security.Security;
import java.util.Base64;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.*;
import java.io.FileReader;
import java.io.Console;


/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        try{
            //load the bouncy castle provider
            java.security.Security.addProvider(new org.bouncycastle.jce.provider.BouncyCastleProvider());
            //Override the default max key strength limitation of 128bits for this app so we can do AES256
            Security.setProperty("crypto.policy", "unlimited");
            
            System.out.println("Welcome to ECDH and AES-256-CBC cross platform test!!!");

            // parsing file "Payment.json"
            Object obj = new JSONParser().parse(new FileReader("./resources/PACS.008-Payment.json"));
            // typecasting obj to JSONObject
            JSONObject jo = (JSONObject) obj;

            System.out.println("Loading Alice's keys from PEMs...");
            //Load Alice's Keys (her prviate key also contains her public key);
            PublicKey alicePublicKey = PemUtils.readPublicKeyFromFile("./resources/alice_pub.pem", "EC");
            KeyPair alicePrivateKey = PemUtils.readKeyPair("./resources/alice.pem", "EC");
            if ((alicePrivateKey != null ) && (alicePublicKey != null)) {
                System.out.println("Alice's keys created successfully");
            }
            else {
                System.out.println("Failed to load Alice's keys");
                System.exit(1);
            }

            //Load Bob's Keys (his prviate key also contains his public key);
            PublicKey  bobPublicKey = PemUtils.readPublicKeyFromFile("./resources/bob_pub.pem", "EC");
            KeyPair bobPrivateKey = PemUtils.readKeyPair("./resources/bob.pem", "EC");
            if ((bobPrivateKey != null ) && (bobPublicKey != null)) {
                System.out.println("Bob's keys created successfully");
            }
            else {
                System.out.println("Failed to load Bob's keys");
                System.exit(1);
            }


            System.out.println("Performing ECDH key exchange");

            byte [] aliceSecret = CryptoUtils.ECDHKeyExchange(alicePrivateKey.getPrivate(), bobPublicKey);
            byte [] bobSecret = CryptoUtils.ECDHKeyExchange(bobPrivateKey.getPrivate(), alicePublicKey);

            System.out.println("Shared Secret before SHA256 (in b64): " + Base64.getEncoder().encodeToString(aliceSecret));
            
            if(!Base64.getEncoder().encodeToString(aliceSecret).equals(Base64.getEncoder().encodeToString(bobSecret))){
                System.out.println("Alice and Bob's shared secrets do not match!");
                System.exit(1);
            } 

            byte [] aliceSecretKey = CryptoUtils.sha256(aliceSecret);
            byte [] bobSecretKey = CryptoUtils.sha256(bobSecret);
            System.out.println("Shared Secret after SHA256. To be used for encryption (in b64): " + Base64.getEncoder().encodeToString(aliceSecretKey));

            if(!Base64.getEncoder().encodeToString(aliceSecretKey).equals(Base64.getEncoder().encodeToString(bobSecretKey))){
                System.out.println("Alice and Bob's shared keys do not match!");
                System.exit(1);
            } 

            //create a new random initialisation vector
            byte[] iv = new byte[16];
            SecureRandom.getInstanceStrong().nextBytes(iv);
            System.out.println("..................................................................................");
            System.out.println("Initialisation Vector(IV) (in b64): " + Base64.getEncoder().encodeToString(iv));

            String encrypted = AESUtil.encrypt(jo.toJSONString(), iv, aliceSecretKey);
            System.out.println("Encrypted data using Alice's secret key (in b64): " + encrypted);

            System.out.println("Copy and Paste this IV and Encrypted Data into one of the other language apps.");
            System.out.println("..................................................................................");

            Console console = System.console();
            System.out.println("Paste the IV from the other language app (in b64): ");
            String inputIv = console.readLine();
            System.out.println("Paste the encrypted data from the other language app (in b64): ");
            encrypted = console.readLine();

            String decrypted = AESUtil.decrypt(encrypted, inputIv, bobSecretKey);
            System.out.println("Data decrypted using Bob's secret key: " + decrypted);
            
            obj = new JSONParser().parse(decrypted);
            // typecasting obj to JSONObject
            jo = null;
            jo = (JSONObject) obj;

            if (jo != null ){
                System.out.println("JSON object parses successfully!!!!");
                System.exit(0);
            } 
            else {
                System.out.println("JSON object didn't parse....");
                System.exit(1);
            }

        } catch(Exception e){
            e.printStackTrace();
            System.exit(1);
        }
    }

}
