//Code based on: https://github.com/fukata/AES-256-CBC-Example/blob/master/java/src/AESUtil.java
// but modifired to fit to use base64 strings instead of hex

package com.ecdh_aes.demo;

import java.security.Key;
import java.security.spec.AlgorithmParameterSpec;
import java.util.Base64;

import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

public class AESUtil {

    public static String encrypt(String src, byte[] iv, byte[] key) {
		try {
			Cipher cipher = Cipher.getInstance("AES/CBC/PKCS7Padding");
			cipher.init(Cipher.ENCRYPT_MODE, makeKey(key), makeIv(iv));
			return Base64.getEncoder().encodeToString((cipher.doFinal(src.getBytes())));
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}
	
	public static String decrypt(String src, String iv, byte[] key) {
		String decrypted = "";
		try {
			Cipher cipher = Cipher.getInstance("AES/CBC/PKCS7Padding");
			cipher.init(Cipher.DECRYPT_MODE, makeKey(key), makeIv(iv));
			decrypted = new String(cipher.doFinal(Base64.getDecoder().decode(src)));
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
		return decrypted;
	}
	
	static AlgorithmParameterSpec makeIv(String iv) {
		try {
			return makeIv(Base64.getDecoder().decode(iv));
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	static AlgorithmParameterSpec makeIv(byte[] iv) {
		try {
			return new IvParameterSpec(iv);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	static Key makeKey(byte[] key) {
		try {
			return new SecretKeySpec(key, "AES");
		} catch (Exception e) {
			e.printStackTrace();
        }		
		return null;
	}
}
